const $ = id => document.getElementById(id);
const views = ["homeView","onlineView","lobbyView","gameView"];
let socket = null, roomCode = null, online = false, roomState = null;
let localPlayers = [], currentPlayer = 0, round = 0, game = "tod", kind = "truth", lastPrompt = "";
let localScores = [0,0], onlineName = "";

const decks = {
 truth: [
  "Hal kecil apa yang selalu bisa memperbaiki harimu?",
  "Apa kesan pertamamu tentang orang di sebelahmu?",
  "Kapan terakhir kali kamu merasa benar-benar dihargai?",
  "Apa satu kebiasaan unik yang belum banyak orang tahu?",
  "Hal apa yang ingin lebih sering kita lakukan bersama?",
  "Apa momen sederhana yang paling kamu ingat belakangan ini?",
  "Apa hal yang membuatmu merasa nyaman menjadi diri sendiri?",
  "Kalau bisa mengulang satu hari menyenangkan, hari apa itu?",
  "Apa pujian yang paling membekas buatmu?",
  "Apa satu hal baru yang ingin kamu pelajari bersama?"
 ],
 dare: [
  "Berikan pujian tulus dengan menyebutkan hal yang spesifik.",
  "Tirukan gaya bicara satu sama lain selama 20 detik.",
  "Pilih satu lagu yang menggambarkan suasana hatimu sekarang.",
  "Ceritakan kenangan lucu kalian dengan gaya pembawa berita.",
  "Buat julukan lucu untuk satu sama lain selama satu ronde.",
  "Gambarkan pasanganmu dalam tiga kata tanpa menyebut fisik.",
  "Buat pantun spontan tentang hari ini.",
  "Lakukan pose foto paling dramatis selama lima detik.",
  "Sebutkan tiga hal kecil yang kamu syukuri hari ini.",
  "Buat rencana kencan sederhana dengan anggaran minim."
 ],
 quiz: [
  "Minuman apa yang paling mungkin dipilih pasanganmu?",
  "Apa kegiatan yang paling membuat pasanganmu rileks?",
  "Kalau punya satu hari kosong, apa pilihan pasanganmu?",
  "Hal apa yang paling sering membuat pasanganmu tertawa?",
  "Apa genre film yang paling disukai pasanganmu?",
  "Apa makanan yang bisa membuat pasanganmu semangat?"
 ],
 rather: [
  "Liburan ke pantai atau menjelajah pegunungan?",
  "Malam film di rumah atau jalan spontan ke luar?",
  "Punya banyak waktu luang atau banyak kesempatan mencoba hal baru?",
  "Makan makanan favorit berulang kali atau mencoba menu baru?",
  "Chat panjang atau telepon singkat tapi rutin?",
  "Sunrise bersama atau melihat city lights malam hari?"
 ],
 thisthat: [
  "Teh atau kopi?",
  "Hujan atau cuaca cerah?",
  "Film atau serial?",
  "Pedas atau manis?",
  "Pagi atau malam?",
  "Foto candid atau foto pose?",
  "Pesan suara atau pesan teks?",
  "Rencana matang atau spontan?"
 ]
};
const titles = {tod:"Truth or Dare",quiz:"How Well Do You Know Me?",rather:"Would You Rather",thisthat:"This or That"};
const labels = {truth:"A MOMENT OF HONESTY",dare:"A LITTLE CHALLENGE",quiz:"HOW WELL DO YOU KNOW?",rather:"TWO POSSIBLE WORLDS",thisthat:"QUICK LITTLE CHOICE"};

function showView(id){views.forEach(v=>$(v).classList.toggle("active",v===id));window.scrollTo({top:0,behavior:"smooth"});}
function toast(msg){const el=$("toast");el.textContent=msg;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2200);}
function connect(){if(socket)return socket;socket=io();socket.on("connect",()=>{$("connectionLabel").textContent=online?"Online connected":"Local play ready";});socket.on("disconnect",()=>{$("connectionLabel").textContent="Connection lost";});socket.on("room:update",room=>{roomState=room;renderLobby();});socket.on("game:turn-result",data=>{roomState=data.room;renderScores();$("roundLabel").textContent=`ROUND ${String(roomState.round).padStart(2,"0")}`;$("turnLine").textContent=`GILIRAN ${roomState.players[roomState.current]?.name?.toUpperCase()||"PEMAIN"}`;if(data.last){$("promptKicker").textContent=data.last.kind.toUpperCase()+" · "+data.last.player.toUpperCase();$("promptText").textContent=data.last.prompt;lastPrompt=data.last.prompt;}});return socket;}
function startLocal(){online=false;localPlayers=[prompt("Nama pemain pertama?","You"),prompt("Nama pemain kedua?","Alya")].map((x,i)=>(x||`Player ${i+1}`).slice(0,18));currentPlayer=0;round=0;localScores=[0,0];game="tod";setupGame();showView("gameView");}
function setupGame(){ $("gameTitle").textContent=titles[game];$("modeTabs").style.display=game==="tod"?"flex":"none";kind="truth";document.querySelectorAll(".mode-tab").forEach(b=>b.classList.toggle("active",b.dataset.kind===kind));$("roundLabel").textContent=`ROUND ${String(round+1).padStart(2,"0")}`;renderTurn();$("promptKicker").textContent=labels[kind]||labels[game];$("promptText").textContent="Tekan tombol di bawah untuk membuka kartu pertamamu.";renderScores();}
function renderTurn(){const name=online?(roomState?.players?.[roomState.current]?.name||"Pemain"):(localPlayers[currentPlayer]||"Pemain");$("turnLine").textContent=`GILIRAN ${name.toUpperCase()}`;}
function renderScores(){if(online&&roomState){$("scoreLabel").textContent=roomState.players.map(p=>p.score).join(" — ");}else $("scoreLabel").textContent=localScores.join(" — ");}
function renderLobby(){if(!roomState)return;$("displayCode").textContent=roomState.code;$("playersList").innerHTML="";roomState.players.forEach((p,i)=>{const d=document.createElement("div");d.className="player-tile";d.innerHTML=`<div class="player-avatar">${i===0?"✦":"♡"}</div><strong></strong><small>${i===0?"HOST":"PLAYER 2"} · READY</small>`;d.querySelector("strong").textContent=p.name;$("playersList").appendChild(d);});if(roomState.players.length<2){const d=document.createElement("div");d.className="player-tile";d.innerHTML='<div class="player-avatar">…</div><strong>Menunggu pemain</strong><small>SHARE YOUR ROOM CODE</small>';$("playersList").appendChild(d);}const ready=roomState.players.length===2;$("lobbyStart").disabled=!ready;$("lobbyHint").textContent=ready?"Kalian sudah lengkap. Saatnya bermain!":"Menunggu pemain kedua...";}
function goOnline(){online=true;showView("onlineView");connect();}
$("startLocal").addEventListener("click",startLocal);
$("openOnline").addEventListener("click",goOnline);
document.querySelectorAll("[data-back]").forEach(b=>b.addEventListener("click",()=>showView("homeView")));
document.querySelectorAll("[data-game]").forEach(b=>b.addEventListener("click",()=>{game=b.dataset.game;if(!localPlayers.length){localPlayers=["You","Alya"];}online=false;round=0;localScores=[0,0];setupGame();showView("gameView");}));
$("createRoom").addEventListener("click",()=>{onlineName=$("onlineName").value.trim()||"Player 1";connect().emit("room:create",{name:onlineName},res=>{if(!res.ok)return $("onlineError").textContent=res.error;roomCode=res.room.code;roomState=res.room;showView("lobbyView");renderLobby();});});
$("joinRoom").addEventListener("click",()=>{onlineName=$("onlineName").value.trim()||"Player 2";const code=$("roomCode").value.trim().toUpperCase();if(code.length!==6){$("onlineError").textContent="Masukkan kode room 6 karakter.";return;}connect().emit("room:join",{name:onlineName,code},res=>{if(!res.ok)return $("onlineError").textContent=res.error;roomCode=code;roomState=res.room;showView("lobbyView");renderLobby();});});
$("roomCode").addEventListener("input",e=>e.target.value=e.target.value.toUpperCase().replace(/[^A-Z0-9]/g,""));
$("copyCode").addEventListener("click",async()=>{try{await navigator.clipboard.writeText(roomCode);toast("Kode room berhasil disalin.");}catch{toast("Kode room: "+roomCode);}});
$("lobbyStart").addEventListener("click",()=>{if(roomState?.players.length!==2)return;game="tod";round=roomState.round||0;setupGame();showView("gameView");});
$("leaveRoom").addEventListener("click",leaveOnline);
function leaveOnline(){if(socket&&roomCode)socket.emit("room:leave",{code:roomCode});roomCode=null;roomState=null;showView("homeView");}
$("gameExit").addEventListener("click",()=>{if(online)leaveOnline();else showView("homeView");});
document.querySelectorAll(".mode-tab").forEach(b=>b.addEventListener("click",()=>{kind=b.dataset.kind;document.querySelectorAll(".mode-tab").forEach(x=>x.classList.toggle("active",x===b));$("promptKicker").textContent=labels[kind];$("promptText").textContent="Mode dipilih. Ambil kartu saat siap."; }));
function drawPrompt(){const deck=game==="tod"?decks[kind]:decks[game];let p=deck[Math.floor(Math.random()*deck.length)];if(deck.length>1&&p===lastPrompt)p=deck[(deck.indexOf(p)+1)%deck.length];lastPrompt=p;$("promptKicker").textContent=labels[kind]||labels[game];$("promptText").textContent=p;round++;$("roundLabel").textContent=`ROUND ${String(round).padStart(2,"0")}`;if(online){connect().emit("game:turn",{code:roomCode,kind:game==="tod"?kind:game, prompt:p},res=>{if(!res.ok)toast(res.error);});}else{currentPlayer=(currentPlayer+1)%2;renderTurn();if(game==="tod"&&kind==="dare")localScores[currentPlayer===0?1:0]++;renderScores();}}
$("nextPrompt").addEventListener("click",drawPrompt);
$("skipPrompt").addEventListener("click",()=>{if(online){connect().emit("game:score",{code:roomCode,amount:0});}else{currentPlayer=(currentPlayer+1)%2;renderTurn();}toast("Tidak apa-apa, kartu berikutnya!");});
