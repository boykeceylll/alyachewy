# alyachewy — Couple Games

Web game pasangan dengan Truth or Dare sebagai permainan utama, plus How Well, Would You Rather, dan This or That.

## Fitur
- Mode lokal: dua pemain bergantian di satu perangkat.
- Mode online: room privat dengan kode 6 karakter, maksimal dua pemain.
- Giliran dan skor tersinkron melalui Socket.IO.
- Desain responsif untuk ponsel dan desktop.
- Konten ringan, aman, dan setiap pemain boleh melewati kartu.

## Menjalankan di komputer
Butuh Node.js 18 atau lebih baru.

```bash
npm install
npm start
```
Buka `http://localhost:3000`.

## Deploy online
Aplikasi ini membutuhkan hosting yang menjalankan Node.js dan mendukung WebSocket (misalnya Render atau Railway). Jangan deploy hanya sebagai static site di Netlify karena server Socket.IO harus tetap berjalan.

### Contoh Render
1. Unggah folder project ke GitHub.
2. Buat Web Service baru di Render dan hubungkan repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Deploy. Buka URL yang diberikan Render.

## Catatan
- Room dan skor online disimpan di memori server. Jika server restart atau tidur, room aktif akan hilang.
- Mode lokal berjalan di browser tanpa akun.
- Untuk penggunaan publik jangka panjang, tambahkan database, moderasi konten, rate limiting, dan autentikasi opsional.
- Tidak ada kewajiban menjawab atau melakukan tantangan. Pemain bebas melewati kartu.
