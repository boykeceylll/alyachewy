const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;

app.use(express.static("public"));
app.get("/health", (_, res) => res.json({ ok: true, app: "alyachewy" }));

const rooms = new Map();
const makeCode = () => crypto.randomBytes(3).toString("hex").toUpperCase();

function publicRoom(room) {
  return {
    code: room.code,
    players: room.players.map(p => ({ name: p.name, score: p.score, ready: p.ready })),
    current: room.current,
    round: room.round,
    mode: room.mode,
    last: room.last
  };
}
function emitRoom(room) {
  io.to(room.code).emit("room:update", publicRoom(room));
}
function cleanName(value) {
  return String(value || "Player").trim().replace(/[<>]/g, "").slice(0, 18) || "Player";
}

io.on("connection", socket => {
  socket.on("room:create", ({ name }, cb = () => {}) => {
    let code;
    do { code = makeCode(); } while (rooms.has(code));
    const room = { code, players: [{ id: socket.id, name: cleanName(name), score: 0, ready: true }], current: 0, round: 0, mode: "tod", last: null };
    rooms.set(code, room);
    socket.join(code);
    cb({ ok: true, room: publicRoom(room) });
    emitRoom(room);
  });

  socket.on("room:join", ({ code, name }, cb = () => {}) => {
    const room = rooms.get(String(code || "").toUpperCase());
    if (!room) return cb({ ok: false, error: "Room tidak ditemukan. Periksa kode undangan." });
    if (room.players.length >= 2) return cb({ ok: false, error: "Room sudah penuh. Maksimal dua pemain." });
    if (room.players.some(p => p.id === socket.id)) return cb({ ok: true, room: publicRoom(room) });
    room.players.push({ id: socket.id, name: cleanName(name), score: 0, ready: true });
    socket.join(room.code);
    cb({ ok: true, room: publicRoom(room) });
    emitRoom(room);
  });

  socket.on("game:turn", ({ code, player, kind, prompt }, cb = () => {}) => {
    const room = rooms.get(String(code || "").toUpperCase());
    if (!room) return cb({ ok: false, error: "Room sudah tidak tersedia." });
    if (room.players.length !== 2) return cb({ ok: false, error: "Tunggu sampai dua pemain bergabung." });
    const sender = room.players.find(p => p.id === socket.id);
    if (!sender) return cb({ ok: false, error: "Kamu bukan anggota room ini." });
    room.last = { player: sender.name, kind, prompt: String(prompt || "").slice(0, 240) };
    room.round += 1;
    room.current = (room.current + 1) % 2;
    io.to(room.code).emit("game:turn-result", { last: room.last, room: publicRoom(room) });
    cb({ ok: true });
  });

  socket.on("game:score", ({ code, amount }, cb = () => {}) => {
    const room = rooms.get(String(code || "").toUpperCase());
    if (!room) return cb({ ok: false });
    const player = room.players.find(p => p.id === socket.id);
    if (!player) return cb({ ok: false });
    player.score = Math.max(0, player.score + Math.max(-5, Math.min(5, Number(amount) || 0)));
    emitRoom(room);
    cb({ ok: true });
  });

  socket.on("room:leave", ({ code }) => {
    const room = rooms.get(String(code || "").toUpperCase());
    if (!room) return;
    room.players = room.players.filter(p => p.id !== socket.id);
    socket.leave(room.code);
    if (!room.players.length) rooms.delete(room.code);
    else { room.current = 0; emitRoom(room); }
  });

  socket.on("disconnect", () => {
    for (const [code, room] of rooms) {
      const before = room.players.length;
      room.players = room.players.filter(p => p.id !== socket.id);
      if (room.players.length !== before) {
        if (!room.players.length) rooms.delete(code);
        else { room.current = 0; emitRoom(room); }
      }
    }
  });
});

server.listen(PORT, () => console.log(`Alyachewy running on http://localhost:${PORT}`));
